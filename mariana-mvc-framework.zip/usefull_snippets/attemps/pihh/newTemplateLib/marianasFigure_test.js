/**
 * Created by fsa on 11/01/2016.
 */
'use strict';

describe("Scope", function(){

});