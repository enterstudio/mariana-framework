<?php namespace Mariana\Framework;

abstract class Middleware{

    public function __construct(){

    }
}