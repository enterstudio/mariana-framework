/**
 * Created by fsa on 10/01/2016.
 */

/*
<a href="javascript:history.back(1)">Previous Page</a>
<a href="javascript:history.back(-1)">Next Page</a>
    */