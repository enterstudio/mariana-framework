<?php
use Mariana\Framework\Model;

class Sessions extends Model{

    public function __construct(){
        // static echo get_called_class()
        //echo get_class($this);
    }

}
