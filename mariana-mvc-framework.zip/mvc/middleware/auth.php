<?php

use Mariana\Framework\Middleware;

class Auth extends Middleware{

    public function check(){

    }
}