<?php


echo ("Server running at http://localhost:8000. To quit press CTRL + C");
echo exec('php -S localhost:8000');
